fruits = ["Orange", "Banana", "Apple"]
x, y, z = fruits

print(x, end=" ")
print(y, end=" ")
print(z)