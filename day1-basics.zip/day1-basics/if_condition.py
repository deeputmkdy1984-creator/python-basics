if 50>25:

    print("Welcome to the World of Python")

if 50<25:

    print("Bye Bye Bye")