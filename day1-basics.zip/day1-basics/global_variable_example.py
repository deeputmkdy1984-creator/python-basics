x = 45

def display_number():
    global y
    y = 20
    print(y)

display_number()
print(x + y)