x, y, z = "Blue", "Orange", "White"
print(x)
print(y)
print(z)

x = y = z = "Yellow"
print(x, y, z)