x = 30
y = 20
a = "Thomas "
b = "is "
c = "year old"

print(a, b, x + y, c)